import org.hibernate.Session;
import org.hibernate.query.Query;
import org.hibernate.Transaction;


public class GamesDAO {

    public Games getGameById(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Utiliza el método get para obtener el objeto Games por su ID
            return session.get(Games.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public void insertGame(Session session, Games game) {
        try {
            // Guardar el objeto Games en la base de datos usando la sesión proporcionada
            session.save(game);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void updateGame(Games game) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Iniciar transacción
            transaction = session.beginTransaction();

            // Actualizar el objeto Games en la base de datos
            session.update(game);

            // Commit de la transacción
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                // Rollback en caso de excepción
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    public boolean deleteGameById(int id) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Iniciar transacción
            transaction = session.beginTransaction();

            // Obtener el juego por ID
            Games gameToDelete = session.get(Games.class, id);

            if (gameToDelete != null) {
                // Eliminar el juego de la base de datos
                session.delete(gameToDelete);

                // Commit de la transacción
                transaction.commit();
                return true;
            } else {
                // No se encontró el juego con el ID proporcionado
                System.out.println("No se encontró un juego con el ID proporcionado.");
                return false;
            }
        } catch (Exception e) {
            if (transaction != null) {
                // Rollback en caso de excepción
                transaction.rollback();
            }
            e.printStackTrace();
            return false;
        }
    }
}

