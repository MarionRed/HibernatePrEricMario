public class Main {
    public static void main(String[] args) {
        // Llamar al CSVLoader para cargar datos desde el archivo CSV a la base de datos
        CSVLoader csvLoader = new CSVLoader();
        csvLoader.loadData();
    }
}

