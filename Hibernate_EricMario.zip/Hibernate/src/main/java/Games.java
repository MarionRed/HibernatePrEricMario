import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Games {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private int year;
    private String team;
    private int wins;
    private int losses;


    // Constructor vacío necesario para Hibernate
    public Games() {
    }

    // Constructor con todos los parámetros
    public Games(int year, String team, int wins, int losses) {
        this.year = year;
        this.team = team;
        this.wins = wins;
        this.losses = losses;
    }

    // Getters y setters (uno por cada propiedad)
    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public int getLosses() {
        return losses;
    }

    public void setLosses(int losses) {
        this.losses = losses;
    }
}