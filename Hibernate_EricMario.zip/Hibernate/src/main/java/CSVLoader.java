import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.hibernate.Session;
import org.hibernate.Transaction;


public class CSVLoader {

    public void insertGame(Games game) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Iniciar transacción
            transaction = session.beginTransaction();

            // Guardar el objeto Games en la base de datos
            session.saveOrUpdate(game);

            // Commit de la transacción
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                // Rollback en caso de excepción
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void loadData() {
        String archivoCSV = "C:\\Users\\34673\\Desktop\\team_stats_2003_2023.csv";

        try (Reader reader = new FileReader(archivoCSV);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader())) {

            GamesDAO gamesDAO = new GamesDAO();

            // Iniciar transacción fuera del bucle
            Transaction transaction = null;
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
                transaction = session.beginTransaction();

                for (CSVRecord csvRecord : csvParser) {
                    Games game = new Games();
                    String yearString = csvRecord.get("year");
                    if (!yearString.isEmpty()) {
                        game.setYear(Integer.parseInt(yearString));
                    }
                    game.setTeam(csvRecord.get("team"));
                    String winsString = csvRecord.get("wins");
                    if (!winsString.isEmpty()) {
                        game.setWins(Integer.parseInt(winsString));
                    }
                    String lossesString = csvRecord.get("losses");
                    if (!lossesString.isEmpty()) {
                        game.setLosses(Integer.parseInt(lossesString));
                    }

                    // Insertar el juego en la base de datos
                    gamesDAO.insertGame(session, game);
                }

                // Commit de la transacción al final del bucle
                transaction.commit();
            } catch (Exception e) {
                if (transaction != null) {
                    // Rollback en caso de excepción
                    transaction.rollback();
                }
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

