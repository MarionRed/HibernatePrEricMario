import java.util.Scanner;

public class ConsoleApp {

    private static final CSVLoader csvLoader = new CSVLoader();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Seleccione una opción:");
            System.out.println("1. Encontrar datos por Id");
            System.out.println("2. Añadir registro");
            System.out.println("3. Modificar registro");
            System.out.println("4. Eliminar registro");
            System.out.println("5. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    // Cargar datos desde CSV
                    loadCSVData();
                    break;
                case 2:
                    // Añadir registro
                    addRecord();
                    break;
                case 3:
                    // Modificar registro
                    updateRecord();
                    break;
                case 4:
                    // Eliminar registro
                    deleteRecord();
                    break;
                case 5:
                    // Salir del programa
                    System.out.println("Saliendo del programa...");
                    System.exit(0);
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }

    private static void displayRecordById(int id) {
        GamesDAO gamesDAO = new GamesDAO();

        // Utiliza el DAO para obtener el objeto Games por ID
        Games game = gamesDAO.getGameById(id);

        // Verifica si se encontró el registro
        if (game != null) {
            // Muestra la información del juego
            System.out.println("ID: " + game.getYear());
            System.out.println("Año: " + game.getYear());
            System.out.println("Equipo: " + game.getTeam());
            System.out.println("Victorias: " + game.getWins());
            System.out.println("Derrotas: " + game.getLosses());
        } else {
            // Muestra un mensaje si no se encuentra el registro
            System.out.println("No se encontró un registro con el ID proporcionado.");
        }
    }

    private static void loadCSVData() {
        // Pide al usuario que ingrese el ID para mostrar la información específica
        System.out.println("Ingrese el ID del registro que desea visualizar:");
        int id = scanner.nextInt(); // Suponiendo que tienes un objeto Scanner para la entrada del usuario
        displayRecordById(id);
    }


    private static void addRecord() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el año:");
        int year = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer

        System.out.println("Ingrese el nombre del equipo:");
        String team = scanner.nextLine();

        System.out.println("Ingrese el número de victorias:");
        int wins = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer

        System.out.println("Ingrese el número de derrotas:");
        int losses = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer

        // Crear un nuevo objeto Games con la información proporcionada
        Games newGame = new Games(year, team, wins, losses);

        // Insertar el nuevo juego en la base de datos
        csvLoader.insertGame(newGame);
    }

    private static void updateRecord() {
        System.out.println("Ingrese el ID del juego que desea actualizar:");
        int id = scanner.nextInt(); // Suponiendo que tienes un objeto Scanner para la entrada del usuario

        GamesDAO gamesDAO = new GamesDAO();
        Games gameToUpdate = gamesDAO.getGameById(id);

        if (gameToUpdate != null) {
            // Pedir al usuario que ingrese los nuevos datos
            System.out.println("Ingrese el nuevo año:");
            int newYear = scanner.nextInt();
            gameToUpdate.setYear(newYear);

            System.out.println("Ingrese el nuevo nombre del equipo:");
            String newTeam = scanner.next();
            gameToUpdate.setTeam(newTeam);

            System.out.println("Ingrese las nuevas victorias:");
            int newWins = scanner.nextInt();
            gameToUpdate.setWins(newWins);

            System.out.println("Ingrese las nuevas derrotas:");
            int newLosses = scanner.nextInt();
            gameToUpdate.setLosses(newLosses);

            // Actualizar el juego en la base de datos
            gamesDAO.updateGame(gameToUpdate);
            System.out.println("Juego actualizado exitosamente.");
        } else {
            System.out.println("No se encontró el juego. Verifique el ID proporcionado.");
        }
    }
    private static void deleteRecord() {
        System.out.println("Ingrese el ID del juego que desea eliminar:");
        int id = scanner.nextInt(); // Suponiendo que tienes un objeto Scanner para la entrada del usuario

        GamesDAO gamesDAO = new GamesDAO();
        boolean deleted = gamesDAO.deleteGameById(id);

        if (deleted) {
            System.out.println("Juego eliminado exitosamente.");
        } else {
            System.out.println("No se pudo eliminar el juego. Verifique el ID proporcionado.");
        }
    }
}
